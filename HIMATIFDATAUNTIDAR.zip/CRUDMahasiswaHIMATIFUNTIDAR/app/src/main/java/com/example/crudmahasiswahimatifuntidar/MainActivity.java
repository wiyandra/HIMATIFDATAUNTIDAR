package com.example.crudmahasiswahimatifuntidar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    FloatingActionButton fab;
    RecyclerView recyclerView;
    SearchView searchView;
    ArrayList<DataClass> dataList;
    MyAdapter adapter;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            // Initialize views
            recyclerView = findViewById(R.id.recyclerView);
            fab = findViewById(R.id.fab);
            searchView = findViewById(R.id.search);

            // Initialize database helper
            dbHelper = new DBHelper(this);
            dataList = new ArrayList<>();

            // Setup RecyclerView
            GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 1);
            recyclerView.setLayoutManager(gridLayoutManager);

            adapter = new MyAdapter(MainActivity.this, dataList);
            recyclerView.setAdapter(adapter);

            // Load data from SQLite
            loadDataFromSQLite();

            // Setup FAB click listener
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, UploadActivity.class);
                    startActivity(intent);
                }
            });

            // Setup search functionality
            if (searchView != null) {
                searchView.clearFocus();
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        searchList(newText);
                        return true;
                    }
                });
            }

            Log.d("MainActivity", "onCreate completed successfully");
        } catch (Exception e) {
            Log.e("MainActivity", "Error in onCreate: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            // Refresh data when returning to this activity
            loadDataFromSQLite();
            Log.d("MainActivity", "onResume completed");
        } catch (Exception e) {
            Log.e("MainActivity", "Error in onResume: " + e.getMessage());
        }
    }

    private void loadDataFromSQLite() {
        try {
            dataList.clear();
            ArrayList<DataClass> newData = dbHelper.getAllData();
            dataList.addAll(newData);
            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }
            Log.d("MainActivity", "Loaded " + dataList.size() + " items from database");
        } catch (Exception e) {
            Log.e("MainActivity", "Error loading data from SQLite: " + e.getMessage());
        }
    }

    public void searchList(String text) {
        try {
            ArrayList<DataClass> searchList = new ArrayList<>();
            for (DataClass dataClass : dataList) {
                if (dataClass.getDataNama() != null && dataClass.getDataNama().toLowerCase().contains(text.toLowerCase()) ||
                        dataClass.getDataDesc() != null && dataClass.getDataDesc().toLowerCase().contains(text.toLowerCase()) ||
                        dataClass.getDataJabatan() != null && dataClass.getDataJabatan().toLowerCase().contains(text.toLowerCase())) {
                    searchList.add(dataClass);
                }
            }
            if (adapter != null) {
                adapter.searchDataList(searchList);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "Error in search: " + e.getMessage());
        }
    }
}
