package com.example.crudmahasiswahimatifuntidar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;

public class DetailActivity extends AppCompatActivity {

    TextView detailDesc, detailNama, detailJabatan;
    ImageView detailImage;
    FloatingActionButton deleteButton, editButton;

    int itemId = -1;
    String imageUrl = "";
    String nama = "";
    String deskripsi = "";
    String jabatan = "";

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        try {
            // Initialize views
            detailDesc = findViewById(R.id.detailDesc);
            detailImage = findViewById(R.id.detailImage);
            detailNama = findViewById(R.id.detailNama);
            detailJabatan = findViewById(R.id.detailJabatan);
            deleteButton = findViewById(R.id.deleteButton);
            editButton = findViewById(R.id.editButton);

            // Check if views are found
            if (detailDesc == null || detailImage == null || detailNama == null ||
                    detailJabatan == null || deleteButton == null || editButton == null) {
                Log.e("DetailActivity", "Some views not found!");
                Toast.makeText(this, "Error: Views not found", Toast.LENGTH_SHORT).show();
                return;
            }

            // Initialize database helper
            dbHelper = new DBHelper(this);

            // Get data from intent
            Intent intent = getIntent();
            if (intent != null) {
                itemId = intent.getIntExtra("ID", -1);
                nama = intent.getStringExtra("Nama");
                deskripsi = intent.getStringExtra("Deskripsi");
                jabatan = intent.getStringExtra("Jabatan");
                imageUrl = intent.getStringExtra("Image");

                // Debug log
                Log.d("DetailActivity", "Received data:");
                Log.d("DetailActivity", "ID: " + itemId);
                Log.d("DetailActivity", "Nama: " + nama);
                Log.d("DetailActivity", "Deskripsi: " + deskripsi);
                Log.d("DetailActivity", "Jabatan: " + jabatan);
                Log.d("DetailActivity", "Image: " + imageUrl);

                // Set data to views with null checks
                detailNama.setText(nama != null ? nama : "Nama tidak tersedia");
                detailDesc.setText(deskripsi != null ? deskripsi : "Deskripsi tidak tersedia");
                detailJabatan.setText(jabatan != null ? jabatan : "Jabatan tidak tersedia");

                // Load image
                loadImage();
            } else {
                Log.e("DetailActivity", "Intent is null!");
                Toast.makeText(this, "Error: No data received", Toast.LENGTH_SHORT).show();
            }

            // Set click listeners
            editButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("DetailActivity", "Edit button clicked");
                    try {
                        Intent editIntent = new Intent(DetailActivity.this, UpdateActivity.class);
                        editIntent.putExtra("ID", itemId);
                        editIntent.putExtra("Nama", nama);
                        editIntent.putExtra("Deskripsi", deskripsi);
                        editIntent.putExtra("Jabatan", jabatan);
                        editIntent.putExtra("Image", imageUrl);

                        Log.d("DetailActivity", "Starting UpdateActivity with ID: " + itemId);
                        startActivity(editIntent);
                    } catch (Exception e) {
                        Log.e("DetailActivity", "Error starting UpdateActivity: " + e.getMessage());
                        Toast.makeText(DetailActivity.this, "Error opening edit page", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("DetailActivity", "Delete button clicked");
                    showDeleteConfirmation();
                }
            });

            Log.d("DetailActivity", "onCreate completed successfully");
        } catch (Exception e) {
            Log.e("DetailActivity", "Error in onCreate: " + e.getMessage());
            e.printStackTrace();
            Toast.makeText(this, "Error initializing activity", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadImage() {
        try {
            Log.d("DetailActivity", "Loading image: " + imageUrl);

            if (imageUrl != null && !imageUrl.isEmpty()) {
                File imageFile = new File(imageUrl);
                Log.d("DetailActivity", "Image file path: " + imageFile.getAbsolutePath());
                Log.d("DetailActivity", "Image file exists: " + imageFile.exists());

                if (imageFile.exists()) {
                    Log.d("DetailActivity", "Loading image from file");
                    Glide.with(this)
                            .load(imageFile)
                            .placeholder(R.drawable.uploadimg)
                            .error(R.drawable.uploadimg)
                            .into(detailImage);
                } else {
                    Log.d("DetailActivity", "Image file does not exist, using default");
                    detailImage.setImageResource(R.drawable.uploadimg);
                }
            } else {
                Log.d("DetailActivity", "Image URL is null or empty, using default");
                detailImage.setImageResource(R.drawable.uploadimg);
            }
        } catch (Exception e) {
            Log.e("DetailActivity", "Error loading image: " + e.getMessage());
            e.printStackTrace();
            detailImage.setImageResource(R.drawable.uploadimg);
        }
    }

    private void showDeleteConfirmation() {
        try {
            Log.d("DetailActivity", "Showing delete confirmation dialog");
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Hapus Data");
            builder.setMessage("Apakah Anda yakin ingin menghapus data ini?");
            builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Log.d("DetailActivity", "User confirmed delete");
                    deleteData();
                }
            });
            builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Log.d("DetailActivity", "User cancelled delete");
                    dialog.dismiss();
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
            Log.d("DetailActivity", "Delete confirmation dialog shown");
        } catch (Exception e) {
            Log.e("DetailActivity", "Error showing delete confirmation: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void deleteData() {
        try {
            Log.d("DetailActivity", "Attempting to delete data with ID: " + itemId);

            if (itemId != -1) {
                boolean isDeleted = dbHelper.deleteById(itemId);
                Log.d("DetailActivity", "Delete result: " + isDeleted);

                if (isDeleted) {
                    // Delete image file if exists
                    if (imageUrl != null && !imageUrl.isEmpty()) {
                        File imageFile = new File(imageUrl);
                        if (imageFile.exists()) {
                            boolean deleted = imageFile.delete();
                            Log.d("DetailActivity", "Image file deleted: " + deleted);
                        }
                    }
                    Toast.makeText(this, "Data berhasil dihapus", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Gagal menghapus data", Toast.LENGTH_SHORT).show();
                }
            } else {
                Log.e("DetailActivity", "Invalid item ID: " + itemId);
                Toast.makeText(this, "Error: Invalid data ID", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("DetailActivity", "Error deleting data: " + e.getMessage());
            e.printStackTrace();
            Toast.makeText(this, "Terjadi kesalahan saat menghapus data", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data when returning from UpdateActivity
        Log.d("DetailActivity", "onResume called");
    }
}
