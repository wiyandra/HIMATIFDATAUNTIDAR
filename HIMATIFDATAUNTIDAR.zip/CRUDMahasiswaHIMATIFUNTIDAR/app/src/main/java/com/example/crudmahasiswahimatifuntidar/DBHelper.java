package com.example.crudmahasiswahimatifuntidar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "mahasiswa.db";
    private static final int DATABASE_VERSION = 2; // Increment version to force recreation

    // Nama tabel yang benar
    private static final String TABLE_NAME = "mahasiswa";

    // Kolom-kolom tabel
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAMA = "nama";
    private static final String COLUMN_DESKRIPSI = "deskripsi";
    private static final String COLUMN_JABATAN = "jabatan";
    private static final String COLUMN_IMAGE = "image";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAMA + " TEXT, " +
                COLUMN_DESKRIPSI + " TEXT, " +
                COLUMN_JABATAN + " TEXT, " +
                COLUMN_IMAGE + " TEXT)";
        db.execSQL(createTable);
        Log.d("DBHelper", "Table created: " + createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d("DBHelper", "Upgrading database from version " + oldVersion + " to " + newVersion);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert data
    public boolean insertData(String nama, String deskripsi, String jabatan, String image) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAMA, nama);
            values.put(COLUMN_DESKRIPSI, deskripsi);
            values.put(COLUMN_JABATAN, jabatan);
            values.put(COLUMN_IMAGE, image);

            long result = db.insert(TABLE_NAME, null, values);
            Log.d("DBHelper", "Insert result: " + result);
            return result != -1;
        } catch (Exception e) {
            Log.e("DBHelper", "Error inserting data: " + e.getMessage());
            return false;
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    // Get all data
    public ArrayList<DataClass> getAllData() {
        ArrayList<DataClass> dataList = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;

        try {
            db = this.getReadableDatabase();
            String query = "SELECT * FROM " + TABLE_NAME;
            cursor = db.rawQuery(query, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    DataClass data = new DataClass();
                    data.setKey(String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))));
                    data.setDataNama(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAMA)));
                    data.setDataDesc(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESKRIPSI)));
                    data.setDataJabatan(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_JABATAN)));
                    data.setDataImage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE)));
                    dataList.add(data);
                } while (cursor.moveToNext());
            }
            Log.d("DBHelper", "Retrieved " + dataList.size() + " records");
        } catch (Exception e) {
            Log.e("DBHelper", "Error getting all data: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }

        return dataList;
    }

    // Update data
    public boolean updateData(int id, String nama, String deskripsi, String jabatan, String image) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAMA, nama);
            values.put(COLUMN_DESKRIPSI, deskripsi);
            values.put(COLUMN_JABATAN, jabatan);
            values.put(COLUMN_IMAGE, image);

            int result = db.update(TABLE_NAME, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
            Log.d("DBHelper", "Update result: " + result);
            return result > 0;
        } catch (Exception e) {
            Log.e("DBHelper", "Error updating data: " + e.getMessage());
            return false;
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    // Delete data by ID
    public boolean deleteById(int id) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            int result = db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
            Log.d("DBHelper", "Delete result: " + result);
            return result > 0;
        } catch (Exception e) {
            Log.e("DBHelper", "Error deleting data: " + e.getMessage());
            return false;
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }
}
