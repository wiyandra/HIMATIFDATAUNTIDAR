package com.example.crudmahasiswahimatifuntidar;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private Context context;
    private List<DataClass> dataList;

    public MyAdapter(Context context, List<DataClass> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        try {
            DataClass currentData = dataList.get(position);

            // Set text data with null checks
            holder.recNama.setText(currentData.getDataNama() != null ? currentData.getDataNama() : "");
            holder.recDesc.setText(currentData.getDataDesc() != null ? currentData.getDataDesc() : "");
            holder.recJabatan.setText(currentData.getDataJabatan() != null ? currentData.getDataJabatan() : "");

            // Load image
            if (currentData.getDataImage() != null && !currentData.getDataImage().isEmpty()) {
                File imageFile = new File(currentData.getDataImage());
                if (imageFile.exists()) {
                    Glide.with(context)
                            .load(imageFile)
                            .placeholder(R.drawable.uploadimg)
                            .error(R.drawable.uploadimg)
                            .into(holder.recImage);
                } else {
                    holder.recImage.setImageResource(R.drawable.uploadimg);
                }
            } else {
                holder.recImage.setImageResource(R.drawable.uploadimg);
            }

            // Set click listener
            holder.recCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION && adapterPosition < dataList.size()) {
                        DataClass clickedData = dataList.get(adapterPosition);

                        // Debug log
                        Log.d("MyAdapter", "Item clicked at position: " + adapterPosition);
                        Log.d("MyAdapter", "Sending data:");
                        Log.d("MyAdapter", "ID: " + clickedData.getKey());
                        Log.d("MyAdapter", "Nama: " + clickedData.getDataNama());
                        Log.d("MyAdapter", "Deskripsi: " + clickedData.getDataDesc());
                        Log.d("MyAdapter", "Jabatan: " + clickedData.getDataJabatan());
                        Log.d("MyAdapter", "Image: " + clickedData.getDataImage());

                        Intent intent = new Intent(context, DetailActivity.class);

                        // Send data to DetailActivity with proper error handling
                        try {
                            int id = Integer.parseInt(clickedData.getKey());
                            intent.putExtra("ID", id);
                            Log.d("MyAdapter", "Parsed ID: " + id);
                        } catch (NumberFormatException e) {
                            Log.e("MyAdapter", "Error parsing ID: " + clickedData.getKey());
                            intent.putExtra("ID", -1);
                        }

                        intent.putExtra("Nama", clickedData.getDataNama() != null ? clickedData.getDataNama() : "");
                        intent.putExtra("Deskripsi", clickedData.getDataDesc() != null ? clickedData.getDataDesc() : "");
                        intent.putExtra("Jabatan", clickedData.getDataJabatan() != null ? clickedData.getDataJabatan() : "");
                        intent.putExtra("Image", clickedData.getDataImage() != null ? clickedData.getDataImage() : "");

                        Log.d("MyAdapter", "Starting DetailActivity");
                        context.startActivity(intent);
                    } else {
                        Log.e("MyAdapter", "Invalid adapter position: " + adapterPosition);
                    }
                }
            });
        } catch (Exception e) {
            Log.e("MyAdapter", "Error in onBindViewHolder: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return dataList != null ? dataList.size() : 0;
    }

    public void searchDataList(ArrayList<DataClass> searchList) {
        dataList = searchList;
        notifyDataSetChanged();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView recImage;
        TextView recNama, recDesc, recJabatan;
        CardView recCard;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            recImage = itemView.findViewById(R.id.recImage);
            recCard = itemView.findViewById(R.id.recCard);
            recDesc = itemView.findViewById(R.id.recDesc);
            recJabatan = itemView.findViewById(R.id.recJabatan);
            recNama = itemView.findViewById(R.id.recNama);
        }
    }
}
