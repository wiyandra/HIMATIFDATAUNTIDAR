package com.example.crudmahasiswahimatifuntidar;

public class DataClass {
    private String key;
    private String dataNama;
    private String dataDesc;
    private String dataJabatan;
    private String dataImage;

    public DataClass() {
    }

    public DataClass(String dataNama, String dataDesc, String dataJabatan, String dataImage) {
        this.dataNama = dataNama;
        this.dataDesc = dataDesc;
        this.dataJabatan = dataJabatan;
        this.dataImage = dataImage;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getDataNama() {
        return dataNama;
    }

    public void setDataNama(String dataNama) {
        this.dataNama = dataNama;
    }

    public String getDataDesc() {
        return dataDesc;
    }

    public void setDataDesc(String dataDesc) {
        this.dataDesc = dataDesc;
    }

    public String getDataJabatan() {
        return dataJabatan;
    }

    public void setDataJabatan(String dataJabatan) {
        this.dataJabatan = dataJabatan;
    }

    public String getDataImage() {
        return dataImage;
    }

    public void setDataImage(String dataImage) {
        this.dataImage = dataImage;
    }
}
