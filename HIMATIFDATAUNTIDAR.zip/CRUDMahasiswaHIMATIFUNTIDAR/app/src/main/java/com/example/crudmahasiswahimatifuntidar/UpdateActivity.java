package com.example.crudmahasiswahimatifuntidar;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class UpdateActivity extends AppCompatActivity {

    ImageView updateImage;
    Button updateButton, cancelButton;
    EditText updateNama, updateDesc, updateJabatan;
    String imageURL = "";
    Uri uri;
    DBHelper dbHelper;
    int itemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        try {
            // Initialize views
            updateImage = findViewById(R.id.updateImage);
            updateDesc = findViewById(R.id.updateDesc);
            updateNama = findViewById(R.id.updateNama);
            updateJabatan = findViewById(R.id.updateJabatan);
            updateButton = findViewById(R.id.updateButton);
            cancelButton = findViewById(R.id.cancelButton);

            // Initialize database helper
            dbHelper = new DBHelper(this);

            // Get data from intent
            Intent intent = getIntent();
            if (intent != null) {
                itemId = intent.getIntExtra("ID", -1);
                updateNama.setText(intent.getStringExtra("Nama"));
                updateDesc.setText(intent.getStringExtra("Deskripsi"));
                updateJabatan.setText(intent.getStringExtra("Jabatan"));
                imageURL = intent.getStringExtra("Image");

                // Load existing image
                if (imageURL != null && !imageURL.isEmpty()) {
                    File imageFile = new File(imageURL);
                    if (imageFile.exists()) {
                        Glide.with(this)
                                .load(imageFile)
                                .placeholder(R.drawable.uploadimg)
                                .error(R.drawable.uploadimg)
                                .into(updateImage);
                    }
                }
            }

            // Activity result launcher for image picker
            ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if (result.getResultCode() == Activity.RESULT_OK) {
                                Intent data = result.getData();
                                if (data != null && data.getData() != null) {
                                    uri = data.getData();

                                    // Copy image to internal storage
                                    String savedImagePath = saveImageToInternalStorage(uri);
                                    if (savedImagePath != null) {
                                        imageURL = savedImagePath;
                                        updateImage.setImageURI(Uri.fromFile(new File(savedImagePath)));
                                        Log.d("UpdateActivity", "Image updated: " + savedImagePath);
                                    } else {
                                        Toast.makeText(UpdateActivity.this, "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        }
                    }
            );

            // Set click listeners
            updateImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent photoPicker = new Intent(Intent.ACTION_PICK);
                    photoPicker.setType("image/*");
                    activityResultLauncher.launch(photoPicker);
                }
            });

            updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    updateData();
                }
            });

            // Add cancel button functionality
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish(); // Close activity without saving
                }
            });

            Log.d("UpdateActivity", "onCreate completed successfully");
        } catch (Exception e) {
            Log.e("UpdateActivity", "Error in onCreate: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String saveImageToInternalStorage(Uri imageUri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            if (inputStream != null) {
                // Create a unique filename
                String fileName = "image_" + System.currentTimeMillis() + ".jpg";
                File file = new File(getFilesDir(), fileName);

                FileOutputStream outputStream = new FileOutputStream(file);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }

                outputStream.close();
                inputStream.close();

                Log.d("UpdateActivity", "Image saved successfully: " + file.getAbsolutePath());
                return file.getAbsolutePath();
            }
        } catch (Exception e) {
            Log.e("UpdateActivity", "Error saving image: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public void updateData() {
        try {
            String nama = updateNama.getText().toString().trim();
            String desc = updateDesc.getText().toString().trim();
            String jabatan = updateJabatan.getText().toString().trim();

            if (nama.isEmpty() || desc.isEmpty() || jabatan.isEmpty()) {
                Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                return;
            }

            if (imageURL.isEmpty()) {
                Toast.makeText(this, "Pilih gambar terlebih dahulu", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isUpdated = dbHelper.updateData(itemId, nama, desc, jabatan, imageURL);
            if (isUpdated) {
                Toast.makeText(this, "Data berhasil diupdate! ✅", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Gagal mengupdate data ❌", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("UpdateActivity", "Error updating data: " + e.getMessage());
            Toast.makeText(this, "Terjadi kesalahan saat mengupdate data", Toast.LENGTH_SHORT).show();
        }
    }
}
