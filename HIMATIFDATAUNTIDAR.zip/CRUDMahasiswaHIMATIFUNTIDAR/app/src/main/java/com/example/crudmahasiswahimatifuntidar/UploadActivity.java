package com.example.crudmahasiswahimatifuntidar;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class UploadActivity extends AppCompatActivity {

    ImageView uploadImage;
    Button saveButton;
    EditText uploadNama, uploadDesc, uploadJabatan;
    String imageURL = "";
    Uri uri;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        try {
            // Initialize views
            uploadImage = findViewById(R.id.uploadImage);
            uploadDesc = findViewById(R.id.uploadDesc);
            uploadNama = findViewById(R.id.uploadNama);
            uploadJabatan = findViewById(R.id.uploadJabatan);
            saveButton = findViewById(R.id.saveButton);

            // Initialize database helper
            dbHelper = new DBHelper(this);

            // Activity result launcher for image picker
            ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if (result.getResultCode() == Activity.RESULT_OK) {
                                Intent data = result.getData();
                                if (data != null && data.getData() != null) {
                                    uri = data.getData();

                                    // Copy image to internal storage
                                    String savedImagePath = saveImageToInternalStorage(uri);
                                    if (savedImagePath != null) {
                                        imageURL = savedImagePath;
                                        uploadImage.setImageURI(Uri.fromFile(new File(savedImagePath)));
                                        Log.d("UploadActivity", "Image saved to: " + savedImagePath);
                                    } else {
                                        Toast.makeText(UploadActivity.this, "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        }
                    }
            );

            // Set click listeners
            uploadImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent photoPicker = new Intent(Intent.ACTION_PICK);
                    photoPicker.setType("image/*");
                    activityResultLauncher.launch(photoPicker);
                }
            });

            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    saveData();
                }
            });

            Log.d("UploadActivity", "onCreate completed successfully");
        } catch (Exception e) {
            Log.e("UploadActivity", "Error in onCreate: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String saveImageToInternalStorage(Uri imageUri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            if (inputStream != null) {
                // Create a unique filename
                String fileName = "image_" + System.currentTimeMillis() + ".jpg";
                File file = new File(getFilesDir(), fileName);

                FileOutputStream outputStream = new FileOutputStream(file);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }

                outputStream.close();
                inputStream.close();

                Log.d("UploadActivity", "Image saved successfully: " + file.getAbsolutePath());
                return file.getAbsolutePath();
            }
        } catch (Exception e) {
            Log.e("UploadActivity", "Error saving image: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public void saveData() {
        try {
            String nama = uploadNama.getText().toString().trim();
            String desc = uploadDesc.getText().toString().trim();
            String jabatan = uploadJabatan.getText().toString().trim();

            if (nama.isEmpty() || desc.isEmpty() || jabatan.isEmpty()) {
                Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                return;
            }

            if (imageURL.isEmpty()) {
                Toast.makeText(this, "Pilih gambar terlebih dahulu", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isInserted = dbHelper.insertData(nama, desc, jabatan, imageURL);
            if (isInserted) {
                Toast.makeText(this, "Data berhasil disimpan", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Gagal menyimpan data", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("UploadActivity", "Error saving data: " + e.getMessage());
            Toast.makeText(this, "Terjadi kesalahan saat menyimpan data", Toast.LENGTH_SHORT).show();
        }
    }
}
